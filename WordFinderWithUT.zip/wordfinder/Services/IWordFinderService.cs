namespace wordfinder.Services;

public interface IWordFinderService
{
    /// <summary>
    /// Matrix entered.
    /// </summary>
    IEnumerable<string> Matrix { get; set; }

    /// <summary>
    /// Word entered.
    /// </summary>
    IEnumerable<string> Words { get; set; }

    /// <summary>
    /// Set matrix to build.
    /// </summary>
    void SetMatrix();

    /// <summary>
    /// Set words to find.
    /// </summary>
    /// <returns>List of strings.</returns>
    IEnumerable<string> Find();

    /// <summary>
    /// Get grid elements.
    /// </summary>
    IEnumerable<string> GetGrid();
}