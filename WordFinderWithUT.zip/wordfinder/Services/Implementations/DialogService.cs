using Mopups.Services;
using The49.Maui.BottomSheet;
using wordfinder.Controls;

namespace wordfinder.Services.Implementations;

public class DialogService(IServiceProvider serviceProvider) : IDialogService
{
    #region Public Methods
    
    /// <summary>
    /// Show loading modal.
    /// </summary>
    public async Task ShowLoading()
    {
        await MopupService.Instance.PushAsync(new LoadingModal());
    }

    /// <summary>
    /// Hide loading modal.
    /// </summary>
    public async Task HideLoading()
    {
        await MopupService.Instance.PopAsync();
    }

    /// <summary>
    /// Show bottom sheet.
    /// </summary>
    public async Task ShowSheet(Type page)
    {
        var sheetPage = serviceProvider.GetService(page) as BottomSheet;
        sheetPage.ShowAsync();
    }

    /// <summary>
    /// Show Alert.
    /// </summary>
    public async Task ShowAlert(string title, string message)
    {
        await Application.Current!.MainPage!.DisplayAlert(title, message, "OK");
    }
    
    #endregion
    
}