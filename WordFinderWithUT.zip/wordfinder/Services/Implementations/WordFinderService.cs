namespace wordfinder.Services.Implementations;

public class WordFinderService : IWordFinderService
{
    #region Private Properties
    
    private char[,] _matrix;
    private int _rows;
    private int _cols;

    #endregion
    
    #region Constructor

    public WordFinderService()
    {
        Matrix = [];
        Words = [];
    }

    #endregion
    
    #region Public Methods

    /// <summary>
    /// Matrix entered.
    /// </summary>
    public IEnumerable<string> Matrix { get; set; }

    /// <summary>
    /// Word entered.
    /// </summary>
    public IEnumerable<string> Words { get; set; }

    /// <summary>
    /// Set matrix to build.
    /// </summary>
    public void SetMatrix()
    {
        var matrixList = Matrix.ToList(); // Convert to list for easy indexing.
        _rows = matrixList.Count;
        _cols = matrixList[0].Length;
        _matrix = new char[_rows, _cols];

        for (var i = 0; i < _rows; i++)
        {
            for (var j = 0; j < _cols; j++)
            {
                _matrix[i, j] = matrixList[i][j]; // Set the matrix.
            }
        }

    }

    /// <summary>
    /// Set words to find.
    /// </summary>
    /// <returns>List of strings.</returns>
    public IEnumerable<string> Find()
    {
        var foundWords = new Dictionary<string, int>(); // Dictionary to store found words.
        var uniqueWords = new HashSet<string>(Words); // HashSet to store unique words.
        
        // Check each word in the wordStream to see if it exists in the matrix
        foreach (var word in uniqueWords)
        {
            if (ExistsInMatrix(word)) // Check if the word is present in the matrix.
            {
                foundWords[word] = foundWords.TryGetValue(word, out var value) ? value + 1 : 1; // Add the word to the dictionary.
            }
        }
        
        // Return the top 10 most frequently found words.
        return foundWords.OrderByDescending(w => w.Value).Take(10).Select(w => w.Key);
    }
    
    /// <summary>
    /// Get grid elements.
    /// </summary>
    public IEnumerable<string> GetGrid()
    {
        // Flatten the 2D char array into a list
        var flattenedGrid = new List<string>();

        for (int i = 0; i < _matrix.GetLength(0); i++)
        {
            for (int j = 0; j < _matrix.GetLength(1); j++)
            {
                flattenedGrid.Add(_matrix[i, j].ToString());
            }
        }

        return flattenedGrid;
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Searches for a word in the matrix starting from a given row and column.
    /// </summary>
    /// <param name="word"></param>
    /// <returns></returns>
    private bool ExistsInMatrix(string word)
    {
        // Iterate though each position in the matrix.
        for (var r = 0; r < _rows; r++)
        {
            for (var c = 0; c < _cols; c++)
            {
                if (SearchWord(r, c, word)) // Search for the word form the current position.
                    return true;
            }
        }

        return false;
    }

    /// <summary>
    /// Searches for a word in the matrix starting from a given row and column.
    /// </summary>
    /// <param name="row">Row selected.</param>
    /// <param name="col">Column selected.</param>
    /// <param name="word">Wrod to search.</param>
    private bool SearchWord(int row, int col, string word)
    {
        // Check horizontal from left to right.
        if (col + word.Length <= _cols &&
            Enumerable.Range(0, word.Length).All(i => _matrix[row, col + i] == word[i]))
            return true;
        
        // Check vertical from top to bottom.
        if (row + word.Length <= _rows &&
            Enumerable.Range(0, word.Length).All(i => _matrix[row + i, col] == word[i]))
            return true;

        return false; // Word not found.
    } 

    #endregion
}