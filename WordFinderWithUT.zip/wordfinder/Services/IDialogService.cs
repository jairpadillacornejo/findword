using The49.Maui.BottomSheet;

namespace wordfinder.Services;

public interface IDialogService
{
    /// <summary>
    /// Show loading modal.
    /// </summary>
    Task ShowLoading();

    /// <summary>
    /// Hide loading modal.
    /// </summary>
    Task HideLoading();

    /// <summary>
    /// Show bottom sheet.
    /// </summary>
    Task ShowSheet(Type page);
    
    /// <summary>
    /// Show Alert.
    /// </summary>
    Task ShowAlert(string title, string message);
}