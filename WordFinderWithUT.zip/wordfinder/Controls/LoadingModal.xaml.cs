using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CommunityToolkit.Maui.Views;
using Mopups.Pages;

namespace wordfinder.Controls;

public partial class LoadingModal : PopupPage
{
    public LoadingModal()
    {
        InitializeComponent();
    }
}