using wordfinder.ViewModels;

namespace wordfinder.Views;

public partial class WelcomePage : ContentPage
{
    public WelcomePage(WelcomeViewModel viewModel)
    {
        // TODO there are many ways to assign a ViewModel to the context:
        // 1.- Creating and Interface
        // 2.- Create a custom Navigation to pass that ViewModel integrated with Shell
        // 4.- Using a IServiceProvider.
        // 3.- Injecting the ViewModel in the constructor directly.
        InitializeComponent();
        BindingContext = viewModel;
    }
}