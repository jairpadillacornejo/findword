using The49.Maui.BottomSheet;
using wordfinder.ViewModels.Base;
using wordfinder.ViewModels.Modal;

namespace wordfinder.Views.Modal;

public partial class ConfigurationSheetPage : BottomSheet
{
    public ConfigurationSheetPage(IServiceProvider serviceProvider)
    {
        InitializeComponent();
        BindingContext = serviceProvider.GetService<ConfigurationSheetViewModel>();
        
        Shown += SheetPage_Shown;
    }
    
    /// <summary>
    /// Handle shown event.
    /// </summary>
    private void SheetPage_Shown(object? sender, EventArgs e)
    {
        ((BaseViewModel)BindingContext).Initialize();
        Shown += SheetPage_Shown;
    }
}