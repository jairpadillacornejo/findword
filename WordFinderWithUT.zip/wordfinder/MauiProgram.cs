﻿using CommunityToolkit.Maui;
using Microsoft.Extensions.Logging;
using Mopups.Hosting;
using Syncfusion.Maui.Toolkit.Hosting;
using The49.Maui.BottomSheet;
using wordfinder.Services;
using wordfinder.Services.Implementations;
using wordfinder.ViewModels;
using wordfinder.ViewModels.Modal;
using wordfinder.Views;
using wordfinder.Views.Modal;

namespace wordfinder;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();
        builder
            .UseMauiApp<App>()
            .UseMauiCommunityToolkit()
            .ConfigureSyncfusionToolkit()
            .ConfigureMopups()
            .UseBottomSheet()
            .ConfigureFonts(fonts =>
            {
                fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
            });

#if DEBUG
        builder.Logging.AddDebug();
#endif
        // Register Services.
        builder.Services.AddSingleton<IWordFinderService, WordFinderService>();
        builder.Services.AddSingleton<IDialogService, DialogService>();
        
        // Register ViewModels.
        builder.Services.AddTransient<WelcomeViewModel>();
        builder.Services.AddTransient<ConfigurationSheetViewModel>();
        
        // Register Pages.
        builder.Services.AddTransient<WelcomePage>();
        builder.Services.AddTransient<ConfigurationSheetPage>();
        
        return builder.Build();
    }
}