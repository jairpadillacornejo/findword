using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using wordfinder.Services;
using wordfinder.ViewModels.Base;

namespace wordfinder.ViewModels.Modal;

public partial class ConfigurationSheetViewModel(IWordFinderService wordFinderService, IDialogService dialogService) : BaseViewModel
{
    #region Bindable Properties

    [ObservableProperty]
    private List<string> _resultList = [];

    [ObservableProperty] private ObservableCollection<string> _matrixGrid = [];

    [ObservableProperty] private int _columnsCount;

    #endregion
    
    #region LifeCycle Methods

    /// <summary>
    /// Initialize implementation.
    /// </summary>
    public override async void Initialize()
    {
        await dialogService.ShowLoading();
        ColumnsCount = wordFinderService.Matrix.ToList()[0].Length;
        ResultList = new (wordFinderService.Find());
        MatrixGrid = new(wordFinderService.GetGrid());
        await dialogService.HideLoading();
        base.Initialize();
    }

    #endregion
}