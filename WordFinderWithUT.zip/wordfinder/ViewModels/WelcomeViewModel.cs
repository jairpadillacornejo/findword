using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Microsoft.Maui.Controls.Shapes;
using wordfinder.Resources.Localization;
using wordfinder.Services;
using wordfinder.ViewModels.Base;
using wordfinder.Views.Modal;

namespace wordfinder.ViewModels;

public partial class WelcomeViewModel(IWordFinderService wordFinderService, IDialogService dialogService) : BaseViewModel
{
    #region Bindable Properties

    /// <summary>
    /// Matrix entered.
    /// </summary>
    [ObservableProperty]
    private ObservableCollection<string> _matrixEntered = new (wordFinderService.Matrix.ToList());

    /// <summary>
    /// Words to search entered.
    /// </summary>
    [ObservableProperty] 
    private ObservableCollection<string> _wordsEntered = new (wordFinderService.Words.ToList());

    [ObservableProperty] private string _matrixITem;

    [ObservableProperty] private string _wordItem;

    [ObservableProperty] private int _matrixMaxLength = 64;

    #endregion
    
    #region Private Methods

    /// <summary>
    /// Create matrix handler.
    /// </summary>
    [RelayCommand]
    private void CreateMatrix()
    {
        var clean = MatrixITem.Trim().ToUpper();
        
        // Return if the value is empty.
        if (string.IsNullOrEmpty(clean.Trim()))
            return;
        
        // If the list is empty, set the length of the value to the max
        // now from here all the following values must have the same length.
        if (!MatrixEntered.Any())
        {
            MatrixMaxLength = clean.Length;
            MatrixEntered.Add(clean);
            MatrixITem = string.Empty;
            return;
        }

        // If the value is not the same length as the first value, return.
        if (clean.Length < MatrixMaxLength)
        {
            return;
        }
        
        // Otherwise add it.
        MatrixEntered.Add(clean);
        MatrixITem = string.Empty;
    }

    /// <summary>
    /// Clear matrix handler.
    /// </summary>
    [RelayCommand]
    private void ClearMatrix()
    {
        if (!MatrixEntered.Any()) return;
        
        MatrixMaxLength = 64;
        MatrixEntered.Clear();
    }
    
    /// <summary>
    /// Create words to find handler.
    /// </summary>
    [RelayCommand]
    private void CreateWords()
    {
        WordsEntered.Add(WordItem.Trim().ToUpper());
        WordItem = string.Empty;
    }
    
    /// <summary>
    /// Clear words handler.
    /// </summary>
    [RelayCommand]
    private void ClearWords()
    {
        if (!WordsEntered.Any()) return;
        
        WordsEntered.Clear();
    }

    /// <summary>
    /// Init calculation.
    /// </summary>
    [RelayCommand]
    private async Task FindWords()
    {
        if (WordsEntered.Count == 0 || MatrixEntered.Count == 0)
        {
            await dialogService.ShowAlert(AppResources.MissingInformationTitle , AppResources.MissingInformationMessage);
            return;
        }
        
        wordFinderService.Words = new List<string>(WordsEntered);
        wordFinderService.Matrix = new List<string>(MatrixEntered);
        wordFinderService.SetMatrix();

        await dialogService.ShowSheet(typeof(ConfigurationSheetPage));
    }
    
    #endregion
}