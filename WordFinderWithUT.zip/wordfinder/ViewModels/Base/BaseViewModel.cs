using CommunityToolkit.Mvvm.ComponentModel;

namespace wordfinder.ViewModels.Base;

public class BaseViewModel : ObservableObject
{
    public virtual void Initialize()
    {
    }
}