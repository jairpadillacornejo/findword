using Moq;
using wordfinder.Services;
using wordfinder.ViewModels.Modal;

namespace WordFinder.Test.ViewModels.Modal;

public class ConfigurationSheetViewModelTests
{
    #region Readonly Properties

    private readonly Mock<IWordFinderService> _mockWordFinderService;
    private readonly Mock<IDialogService> _mockDialogService;

    /// <summary>
    /// WelcomeViewModel instance.
    /// </summary>
    private ConfigurationSheetViewModel _viewModel;

    #endregion
    
    /// <summary>
    /// Constructor of <see cref="ConfigurationSheetViewModelTests"/> class.
    /// </summary>
    public ConfigurationSheetViewModelTests()
    {
        _mockWordFinderService = new Mock<IWordFinderService>();
        _mockDialogService = new Mock<IDialogService>();
        
        _viewModel = new ConfigurationSheetViewModel(_mockWordFinderService.Object, _mockDialogService.Object);
    }

    #region Test Methods
    
    /// <summary>
    /// Test initialization.
    /// </summary>
    [Fact]
    public void Init_ShouldCreateConfiguration()
    {
        // Arrange
        _mockDialogService.Setup(mock => mock.ShowLoading()).Returns(Task.CompletedTask);
        _mockDialogService.Setup(mock => mock.HideLoading()).Returns(Task.CompletedTask);
        _mockWordFinderService.Setup(mock => mock.Find()).Returns(new List<string> { "ABC" });
        _mockWordFinderService.Setup(mock => mock.GetGrid()).Returns(new List<string> { "A", "B", "C" });

        // Act
        _viewModel.Initialize();

        // Assert
        Assert.Equal(1, _viewModel.ResultList.Count);
        Assert.Equal(3, _viewModel.MatrixGrid.Count);
        _mockDialogService.Verify(service => service.ShowLoading(), Times.Once);
        _mockDialogService.Verify(service => service.HideLoading(), Times.Once);
    }
    
    #endregion
}