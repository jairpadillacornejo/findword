using Moq;
using wordfinder.Services;
using wordfinder.ViewModels;

namespace WordFinder.Test.ViewModels;

public class WelcomeViewModelTests
{
    /// <summary>
    /// TODO:
    /// Here we can test a lot of scenarios, like the creation of the matrix and its variants
    /// same case for the words to search.
    /// the clear buttons
    /// and the navigation.
    /// </summary>
    #region Readonly Properties

    private readonly Mock<IWordFinderService> _mockWordFinderService;
    private readonly Mock<IDialogService> _mockDialogService;

    /// <summary>
    /// WelcomeViewModel instance.
    /// </summary>
    private WelcomeViewModel _viewModel;

    #endregion
    /// <summary>
    /// Constructor of <see cref="WelcomeViewModelTests"/> class.
    /// </summary>
    public WelcomeViewModelTests()
    {
        _mockWordFinderService = new Mock<IWordFinderService>();
        _mockDialogService = new Mock<IDialogService>();
        
        _viewModel = new WelcomeViewModel(_mockWordFinderService.Object, _mockDialogService.Object);
    }

    #region Test Methods

    /// <summary>
    /// Test creation of matrix.
    /// </summary>
    [Theory]
    [InlineData("abc")]
    [InlineData("abc ")]
    [InlineData(" aBc ")]
    public void Matrix_ShouldCreateMatrix(string matrixItem)
    {
        // Arrange
        _viewModel.MatrixITem = matrixItem;

        // Act
        _viewModel.CreateMatrixCommand.Execute(null);

        // Assert
        Assert.NotEmpty(_viewModel.MatrixEntered);
        Assert.Equal("ABC", _viewModel.MatrixEntered[0]);
    }

    /// <summary>
    /// Test creation of word to search.
    /// </summary>
    [Fact]
    public void Word_ShouldCreateWordList()
    {
        // Arrange
        _viewModel.WordItem = "ABC";

        // Act
        _viewModel.CreateMatrixCommand.Execute(null);

        // Assert
        Assert.NotEmpty(_viewModel.WordsEntered);
    }
    
    #endregion
}