using wordfinder.Services.Implementations;

namespace WordFinder.Test.Services;

public class WordFinderServiceTests
{
    #region Readonly Properties
    /// <summary>
    /// WelcomeViewModel instance.
    /// </summary>
    private WordFinderService _viewModel;

    #endregion
    
    /// <summary>
    /// Constructor of <see cref="WordFinderServiceTests"/> class.
    /// </summary>
    public WordFinderServiceTests()
    {
        _viewModel = new WordFinderService();
    }
    
    #region Test Methods

    /// <summary>
    /// Test matrix creation.
    /// </summary>
    [Fact]
    public void Matrix_ShouldCreateConfiguration()
    {
        // Arrange
        _viewModel.Matrix = ["ABC"];

        // Act
        _viewModel.SetMatrix();

        // Assert
        Assert.Equal(3, _viewModel.GetGrid().Count());
        Assert.True(_viewModel.GetGrid().ToList().Contains("A"));
    }
    
    /// <summary>
    /// Test matrix creation.
    /// </summary>
    [Fact]
    public void Find_ShouldFindWords()
    {
        // Arrange
        _viewModel.Matrix = ["ABCDC", "FGWIO", "CHILL", "PQNSD", "UVDXY"];
        _viewModel.Words = ["COLD", "WIND", "SNOW", "CHILL"];

        // Act
        var result = _viewModel.Find();

        // Assert
        Assert.Equal(3, result.Count());
    }

    #endregion
}